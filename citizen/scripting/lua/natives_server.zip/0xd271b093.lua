--- TASK_REACT_AND_FLEE_PED
function Global.TaskReactAndFleePed(ped, fleeTarget)
	return _in(0x8a632bd8, ped, fleeTarget)
end
