--- DELETE_RESOURCE_KVP
-- @param key The key to delete
function Global.DeleteResourceKvp(key)
	return _in(0x7389b5df, _ts(key))
end
