--- FLAG_SERVER_AS_PRIVATE
function Global.FlagServerAsPrivate(private_)
	return _in(0x13b6855d, private_)
end
