--- For more info and the list of faceIDs please refer to [this](https://gtaforums.com/topic/858970-all-gtao-face-ids-pedset-ped-head-blend-data-explained) topic. Note that the Skin and Shape IDs are shared. This native will use this same list for both Skin and Shape IDs.
-- **Other information:**
-- IDs start at zero and go Male Non-DLC, Female Non-DLC, Male DLC, and Female DLC.
-- This native function is often called prior to calling natives such as:
-- *   [`SetPedHairColor`](#\_0xA23FE32C)
-- *   [`SetPedHeadOverlayColor`](#\_0x78935A27)
-- *   [`SetPedHeadOverlay`](#\_0xD28DBA90)
-- *   [`SetPedFaceFeature`](#\_0x6C8D4458)
-- @param ped The ped entity
-- @param shapeFirstID Controls the shape of the first ped's face
-- @param shapeSecondID Controls the shape of the second ped's face
-- @param shapeThirdID Controls the shape of the third ped's face
-- @param skinFirstID Controls the first id's skin tone
-- @param skinSecondID Controls the second id's skin tone
-- @param skinThirdID Controls the third id's skin tone
-- @param shapeMix 0.0 - 1.0 Of whose characteristics to take Mother -> Father (shapeFirstID and shapeSecondID)
-- @param skinMix 0.0 - 1.0 Of whose characteristics to take Mother -> Father (skinFirstID and skinSecondID)
-- @param thirdMix Overrides the others in favor of the third IDs.
-- @param isParent IsParent is set for "children" of the player character's grandparents during old-gen character creation. It has unknown effect otherwise.
function Global.SetPedHeadBlendData(ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)
	return _in(0x60746b88, ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)
end
